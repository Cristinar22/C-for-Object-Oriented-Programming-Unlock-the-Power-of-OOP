
using System;

public delegate void EngineStartedHandler(string message); // Define the delegate

public class Car
{
    public event EngineStartedHandler EngineStarted; // Declare the event

    public void StartEngine()
    {
        Console.WriteLine("The engine is starting...");
        EngineStarted?.Invoke("The car's engine has started.");
    }
}

class Program
{
    static void Main()
    {
        Car myCar = new Car();

        // Subscribe to the event
        myCar.EngineStarted += (message) => Console.WriteLine(message);

        // Start the engine, which will trigger the event
        myCar.StartEngine();
    }
}
