
public delegate void Notify(); // Delegate definition

public class ProcessOrder
{
    public Notify OnOrderProcessed; // Declare the delegate

    public void Process()
    {
        Console.WriteLine("Processing order...");
        OnOrderProcessed?.Invoke(); // Call the delegate method (if not null)
    }
}
