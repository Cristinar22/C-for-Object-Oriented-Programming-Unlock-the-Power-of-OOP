
public delegate void EventHandler(string message);

public class Button
{
    public event EventHandler ButtonClicked;

    public void Click()
    {
        Console.WriteLine("Button was clicked!");
        ButtonClicked?.Invoke("Button has been clicked!");
    }
}

class Program
{
    static void Main()
    {
        Button button = new Button();
        button.ButtonClicked += (message) => Console.WriteLine(message); // Subscriber
        button.Click(); // Trigger the event
    }
}
