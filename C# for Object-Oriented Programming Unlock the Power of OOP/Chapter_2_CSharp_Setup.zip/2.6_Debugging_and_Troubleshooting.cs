
    // Debugging tips for common issues
    1. If no output is displayed, ensure code is inside the Main method.
    2. Read error messages carefully for missing semicolons or typos.
    3. Make sure Visual Studio is set to use the correct template (.NET Core Console App).
    