
    // Install Visual Studio and Visual Studio Code code
    1. Download and install Visual Studio from the official Visual Studio website.
    2. Choose the '.NET desktop development' workload.
    3. Install Visual Studio Code and C# extension by OmniSharp for syntax highlighting and debugging.
    