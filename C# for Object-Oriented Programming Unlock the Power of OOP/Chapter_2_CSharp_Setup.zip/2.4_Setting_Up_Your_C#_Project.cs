
    // Code for setting up your C# project
    1. Create a new Console Application project in Visual Studio.
    2. Use the 'dotnet new console -n HelloWorldApp' command in VS Code.
    3. Modify the Program.cs file for your project.
    