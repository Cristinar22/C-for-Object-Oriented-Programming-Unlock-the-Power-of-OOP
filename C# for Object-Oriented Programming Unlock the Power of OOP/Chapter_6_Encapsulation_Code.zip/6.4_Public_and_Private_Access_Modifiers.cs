
    public class BankAccount
    {
        // Private field: Balance cannot be accessed directly
        private double balance;

        // Public method to deposit money
        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                balance += amount;
                Console.WriteLine($"Deposited ${amount}. New balance: ${balance}");
            }
            else
            {
                Console.WriteLine("Invalid deposit amount.");
            }
        }

        // Public method to withdraw money
        public void Withdraw(double amount)
        {
            if (amount > 0 && amount <= balance)
            {
                balance -= amount;
                Console.WriteLine($"Withdrew ${amount}. New balance: ${balance}");
            }
            else
            {
                Console.WriteLine("Invalid or insufficient funds.");
            }
        }

        // Public method to get the balance
        public double GetBalance()
        {
            return balance;
        }
    }
    