
    using System;

    public class BankAccount
    {
        // Private field to store balance
        private double balance;

        // Public property to access balance
        public double Balance
        {
            get { return balance; }
            set
            {
                if (value >= 0)
                {
                    balance = value;
                }
                else
                {
                    Console.WriteLine("Error: Balance cannot be negative.");
                }
            }
        }

        // Public method to deposit money
        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                Balance += amount;
                Console.WriteLine($"Deposited: ${amount}. Current Balance: ${Balance}");
            }
            else
            {
                Console.WriteLine("Deposit amount must be positive.");
            }
        }

        // Public method to withdraw money
        public void Withdraw(double amount)
        {
            if (amount <= Balance && amount > 0)
            {
                Balance -= amount;
                Console.WriteLine($"Withdrew: ${amount}. Current Balance: ${Balance}");
            }
            else
            {
                Console.WriteLine("Insufficient funds or invalid amount.");
            }
        }
    }

    class Program
    {
        static void Main()
        {
            // Creating a new BankAccount object
            BankAccount account = new BankAccount();
            
            // Depositing and withdrawing money using methods
            account.Deposit(200);
            account.Withdraw(50);
            account.Deposit(500);
            account.Withdraw(1000);
        }
    }
    