
    public class BankAccount
    {
        private double balance;

        // Property for balance
        public double Balance
        {
            get { return balance; }   // Getter
            set 
            {
                if (value >= 0)        // Setter with validation
                {
                    balance = value;
                }
                else
                {
                    Console.WriteLine("Balance cannot be negative.");
                }
            }
        }

        // Method to deposit money
        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                Balance += amount;  // Using the property to modify balance
                Console.WriteLine($"Deposited ${amount}. New balance: ${Balance}");
            }
        }

        // Method to withdraw money
        public void Withdraw(double amount)
        {
            if (amount > 0 && amount <= Balance)
            {
                Balance -= amount;  // Using the property to modify balance
                Console.WriteLine($"Withdrew ${amount}. New balance: ${Balance}");
            }
            else
            {
                Console.WriteLine("Invalid or insufficient funds.");
            }
        }
    }
    