
public class Singleton
{
    private static Singleton _instance; // Private static variable to hold the single instance

    // Private constructor to prevent instantiation from outside
    private Singleton() 
    {
        Console.WriteLine("Singleton instance created.");
    }

    // Public static method to get the instance of the class
    public static Singleton Instance
    {
        get
        {
            // Create a new instance if it doesn't already exist
            if (_instance == null)
            {
                _instance = new Singleton();
            }
            return _instance;
        }
    }

    public void DisplayMessage()
    {
        Console.WriteLine("Hello from Singleton!");
    }
}

class Program
{
    static void Main()
    {
        // Accessing the Singleton instance
        Singleton singleton1 = Singleton.Instance;
        singleton1.DisplayMessage();

        // Attempting to create another instance (will return the same instance)
        Singleton singleton2 = Singleton.Instance;
        singleton2.DisplayMessage();

        // Check if both instances are the same
        Console.WriteLine(singleton1 == singleton2 ? "Both are the same instance!" : "Instances are different.");
    }
}
    