
using System;
using System.Collections.Generic;

// Define the Observer interface
public interface IObserver
{
    void Update(string message);
}

// Define the Subject class
public class MessagePublisher
{
    private List<IObserver> _observers = new List<IObserver>();

    public void Subscribe(IObserver observer)
    {
        _observers.Add(observer);
    }

    public void Unsubscribe(IObserver observer)
    {
        _observers.Remove(observer);
    }

    public void Notify(string message)
    {
        foreach (var observer in _observers)
        {
            observer.Update(message);
        }
    }
}

// Concrete observer class
public class EmailSubscriber : IObserver
{
    public void Update(string message)
    {
        Console.WriteLine("Email received: " + message);
    }
}

// Another concrete observer class
public class SmsSubscriber : IObserver
{
    public void Update(string message)
    {
        Console.WriteLine("SMS received: " + message);
    }
}

class Program
{
    static void Main()
    {
        // Create the publisher and observers
        var publisher = new MessagePublisher();
        var emailSubscriber = new EmailSubscriber();
        var smsSubscriber = new SmsSubscriber();

        // Subscribe the observers
        publisher.Subscribe(emailSubscriber);
        publisher.Subscribe(smsSubscriber);

        // Notify all observers
        publisher.Notify("New event occurred!");

        // Unsubscribe one observer
        publisher.Unsubscribe(smsSubscriber);

        // Notify again
        publisher.Notify("Another event happened!");
    }
}
    