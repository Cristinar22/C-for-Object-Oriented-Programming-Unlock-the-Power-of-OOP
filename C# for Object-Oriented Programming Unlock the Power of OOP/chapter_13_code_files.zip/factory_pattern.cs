
public interface ICar
{
    void Drive();
}

public class Sedan : ICar
{
    public void Drive()
    {
        Console.WriteLine("Driving a Sedan.");
    }
}

public class SUV : ICar
{
    public void Drive()
    {
        Console.WriteLine("Driving an SUV.");
    }
}

public class CarFactory
{
    public static ICar GetCar(string carType)
    {
        if (carType.Equals("Sedan", StringComparison.OrdinalIgnoreCase))
        {
            return new Sedan();
        }
        else if (carType.Equals("SUV", StringComparison.OrdinalIgnoreCase))
        {
            return new SUV();
        }
        else
        {
            throw new ArgumentException("Invalid car type.");
        }
    }
}

class Program
{
    static void Main()
    {
        // Using the factory to create car objects
        ICar car1 = CarFactory.GetCar("Sedan");
        car1.Drive();

        ICar car2 = CarFactory.GetCar("SUV");
        car2.Drive();
    }
}
    