
public class Product
{
    // Properties
    public string ProductName { get; set; }
    public string ProductCode { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }

    // Constructor to initialize a new product
    public Product(string productName, string productCode, int quantity, decimal price)
    {
        ProductName = productName;
        ProductCode = productCode;
        Quantity = quantity;
        Price = price;
    }

    // Method to display product details
    public void DisplayProductInfo()
    {
        Console.WriteLine($"Product: {ProductName} | Code: {ProductCode} | Quantity: {Quantity} | Price: {Price:C}");
    }
}
    