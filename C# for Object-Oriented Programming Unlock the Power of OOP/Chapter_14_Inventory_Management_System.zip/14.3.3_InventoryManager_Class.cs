
using System;

public class InventoryManager
{
    private Inventory inventory = new Inventory();

    // Method to display the main menu
    public void DisplayMenu()
    {
        Console.Clear();
        Console.WriteLine("Welcome to the Inventory Management System!");
        Console.WriteLine("1. Add a Product");
        Console.WriteLine("2. Remove a Product");
        Console.WriteLine("3. Display All Products");
        Console.WriteLine("4. Exit");
    }

    // Method to execute the selected action
    public void ExecuteAction(int choice)
    {
        switch (choice)
        {
            case 1:
                AddProductToInventory();
                break;
            case 2:
                RemoveProductFromInventory();
                break;
            case 3:
                inventory.DisplayAllProducts();
                break;
            case 4:
                Console.WriteLine("Exiting...");
                break;
            default:
                Console.WriteLine("Invalid choice, please try again.");
                break;
        }
    }

    // Method to handle adding a product
    private void AddProductToInventory()
    {
        Console.Write("Enter Product Name: ");
        string name = Console.ReadLine();
        Console.Write("Enter Product Code: ");
        string code = Console.ReadLine();
        Console.Write("Enter Quantity: ");
        int quantity = int.Parse(Console.ReadLine());
        Console.Write("Enter Price: ");
        decimal price = decimal.Parse(Console.ReadLine());

        Product product = new Product(name, code, quantity, price);
        inventory.AddProduct(product);
    }

    // Method to handle removing a product
    private void RemoveProductFromInventory()
    {
        Console.Write("Enter Product Code to Remove: ");
        string code = Console.ReadLine();
        inventory.RemoveProduct(code);
    }
}
    