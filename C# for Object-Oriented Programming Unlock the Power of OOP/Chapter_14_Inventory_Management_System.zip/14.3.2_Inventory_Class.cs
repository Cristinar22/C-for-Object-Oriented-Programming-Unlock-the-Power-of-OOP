
using System;
using System.Collections.Generic;

public class Inventory
{
    // List to store products
    private List<Product> products = new List<Product>();

    // Method to add a product to the inventory
    public void AddProduct(Product product)
    {
        products.Add(product);
        Console.WriteLine($"{product.ProductName} added to inventory.");
    }

    // Method to remove a product by its code
    public void RemoveProduct(string productCode)
    {
        Product product = products.Find(p => p.ProductCode == productCode);
        if (product != null)
        {
            products.Remove(product);
            Console.WriteLine($"{product.ProductName} removed from inventory.");
        }
        else
        {
            Console.WriteLine("Product not found.");
        }
    }

    // Method to display all products
    public void DisplayAllProducts()
    {
        Console.WriteLine("
All Products in Inventory:");
        foreach (var product in products)
        {
            product.DisplayProductInfo();
        }
    }

    // Method to search for a product by its code
    public Product FindProductByCode(string productCode)
    {
        return products.Find(p => p.ProductCode == productCode);
    }
}
    