
class Program
{
    static void Main()
    {
        InventoryManager manager = new InventoryManager();
        int choice;

        do
        {
            manager.DisplayMenu();
            Console.Write("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());
            manager.ExecuteAction(choice);
            Console.WriteLine("Press any key to return to the menu...");
            Console.ReadKey();
        } while (choice != 4);
    }
}
    