
using System;

class Program
{
    static void Main()
    {
        string greeting = "Hello, world!";
        int year = 2025;
        double price = 9.99;

        Console.WriteLine(greeting);  
        Console.WriteLine("Year: " + year);  
        Console.WriteLine("Price: $" + price);
    }
}
