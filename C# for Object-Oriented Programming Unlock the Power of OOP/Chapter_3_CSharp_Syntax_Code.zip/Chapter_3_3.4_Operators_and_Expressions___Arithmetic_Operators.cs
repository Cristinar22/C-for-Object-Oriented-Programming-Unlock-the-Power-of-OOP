
int a = 10;
int b = 5;

Console.WriteLine(a + b);  
Console.WriteLine(a - b);  
Console.WriteLine(a * b);  
Console.WriteLine(a / b);  
Console.WriteLine(a % b);  
