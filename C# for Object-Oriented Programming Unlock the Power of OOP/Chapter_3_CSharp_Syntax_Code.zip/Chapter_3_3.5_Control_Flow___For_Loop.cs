
for (int i = 0; i < 5; i++)
{
    Console.WriteLine("Iteration " + (i + 1));
}
