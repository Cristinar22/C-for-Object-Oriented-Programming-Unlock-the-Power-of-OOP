
int i = 0;
do
{
    Console.WriteLine("Iteration " + (i + 1));
    i++;
} while (i < 5);
