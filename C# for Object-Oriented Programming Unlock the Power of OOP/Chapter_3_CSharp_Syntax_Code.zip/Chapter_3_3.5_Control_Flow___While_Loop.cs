
int i = 0;
while (i < 5)
{
    Console.WriteLine("Iteration " + (i + 1));
    i++;
}
