
bool isRaining = true;
bool hasUmbrella = false;

Console.WriteLine(isRaining && hasUmbrella);  
Console.WriteLine(isRaining || hasUmbrella);  
Console.WriteLine(!isRaining);  
