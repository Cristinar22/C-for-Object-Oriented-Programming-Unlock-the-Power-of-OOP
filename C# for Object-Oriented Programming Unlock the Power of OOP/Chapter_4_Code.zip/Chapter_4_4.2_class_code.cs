public class Car
{
    // Properties (attributes)
    public string color;
    public string model;
    public int speed;

    // Methods (behaviors)
    public void Start()
    {
        Console.WriteLine("The car is starting.");
    }

    public void Stop()
    {
        Console.WriteLine("The car has stopped.");
    }
}