class Program
{
    static void Main()
    {
        // Creating objects from the Car class
        Car car1 = new Car();
        car1.color = "Red";
        car1.model = "Sedan";
        car1.speed = 120;

        Car car2 = new Car();
        car2.color = "Blue";
        car2.model = "SUV";
        car2.speed = 100;

        // Calling methods on the objects
        car1.Start();
        car2.Stop();
    }
}