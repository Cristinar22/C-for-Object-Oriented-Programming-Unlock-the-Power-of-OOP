public class Dog
{
    // Properties (attributes)
    public string Name;
    public int Age;
    public string Breed;

    // Method (behavior)
    public void Bark()
    {
        Console.WriteLine(Name + " is barking!");
    }

    public void Play()
    {
        Console.WriteLine(Name + " is playing!");
    }
}