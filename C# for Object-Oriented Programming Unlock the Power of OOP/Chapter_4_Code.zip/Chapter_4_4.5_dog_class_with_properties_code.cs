public class Dog
{
    // Auto-implemented properties
    public string Name { get; set; }
    public int Age { get; set; }
    public string Breed { get; set; }

    // Method
    public void Bark()
    {
        Console.WriteLine(Name + " is barking!");
    }

    public void Play()
    {
        Console.WriteLine(Name + " is playing!");
    }
}