public class Dog
{
    private int _age;
    
    public string Name { get; set; }
    public string Breed { get; set; }

    // Custom getter and setter for Age
    public int Age
    {
        get { return _age; }
        set
        {
            if (value >= 0)
                _age = value;
            else
                Console.WriteLine("Age cannot be negative.");
        }
    }

    public void Bark()
    {
        Console.WriteLine(Name + " is barking!");
    }

    public void Play()
    {
        Console.WriteLine(Name + " is playing!");
    }
}