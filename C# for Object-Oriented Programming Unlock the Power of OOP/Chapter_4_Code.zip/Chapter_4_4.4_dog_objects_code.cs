class Program
{
    static void Main()
    {
        // Creating two Dog objects
        Dog dog1 = new Dog();
        dog1.Name = "Buddy";
        dog1.Age = 3;
        dog1.Breed = "Golden Retriever";

        Dog dog2 = new Dog();
        dog2.Name = "Lucy";
        dog2.Age = 5;
        dog2.Breed = "Beagle";

        // Calling methods on the objects
        dog1.Bark();
        dog2.Play();
    }
}