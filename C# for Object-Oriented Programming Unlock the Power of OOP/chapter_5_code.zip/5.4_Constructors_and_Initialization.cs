public class Dog
{
    // Properties (attributes)
    public string Name;
    public int Age;

    // Constructor
    public Dog(string name, int age)
    {
        Name = name;
        Age = age;
    }

    // Method (behavior)
    public void Bark()
    {
        Console.WriteLine(Name + " says woof!");
    }
}

class Program
{
    static void Main()
    {
        // Creating an instance (object) of the Dog class using the constructor
        Dog dog1 = new Dog("Buddy", 3);

        // Calling the method on the dog1 object
        dog1.Bark();
    }
}
