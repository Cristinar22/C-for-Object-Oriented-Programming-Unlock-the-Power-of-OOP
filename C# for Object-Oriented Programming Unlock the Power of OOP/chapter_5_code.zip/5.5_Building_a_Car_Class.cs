public class Car
{
    // Properties (attributes)
    public string Make;
    public string Model;
    public int Year;

    // Constructor
    public Car(string make, string model, int year)
    {
        Make = make;
        Model = model;
        Year = year;
    }

    // Methods (behaviors)
    public void Drive()
    {
        Console.WriteLine(Make + " " + Model + " is driving!");
    }

    public void Stop()
    {
        Console.WriteLine(Make + " " + Model + " has stopped.");
    }
}

class Program
{
    static void Main()
    {
        // Creating Car objects using the constructor
        Car car1 = new Car("Toyota", "Camry", 2022);
        Car car2 = new Car("Honda", "Civic", 2021);

        // Calling methods on the car objects
        car1.Drive();
        car2.Stop();
    }
}
