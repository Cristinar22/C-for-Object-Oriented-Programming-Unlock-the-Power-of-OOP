public class Car
{
    // Properties (attributes)
    public string Make;
    public string Model;
    public int Year;

    // Constructor with all parameters
    public Car(string make, string model, int year)
    {
        Make = make;
        Model = model;
        Year = year;
    }

    // Constructor with default year
    public Car(string make, string model)
    {
        Make = make;
        Model = model;
        Year = 2020;  // Default year
    }

    // Methods (behaviors)
    public void Drive()
    {
        Console.WriteLine(Make + " " + Model + " is driving!");
    }

    public void Stop()
    {
        Console.WriteLine(Make + " " + Model + " has stopped.");
    }
}

class Program
{
    static void Main()
    {
        // Using the first constructor
        Car car1 = new Car("Toyota", "Camry", 2022);

        // Using the second constructor (defaults to year 2020)
        Car car2 = new Car("Honda", "Civic");

        car1.Drive();
        car2.Stop();
    }
}
