public class Dog
{
    // Properties (attributes)
    public string Name;
    public int Age;
    
    // Method (behavior)
    public void Bark()
    {
        Console.WriteLine(Name + " says woof!");
    }
}

class Program
{
    static void Main()
    {
        // Creating an instance (object) of the Dog class
        Dog dog1 = new Dog();
        dog1.Name = "Buddy";
        dog1.Age = 3;

        // Calling the method on the dog1 object
        dog1.Bark();
    }
}
