
public interface IShape
{
    void Draw(); // No implementation here
    double Area(); // No implementation here
}
