
public abstract class Shape
{
    // Common property for all shapes
    public string Color { get; set; }

    // Abstract method (to be implemented by derived classes)
    public abstract void Draw(); 

    // A non-abstract method with a defined implementation
    public void PrintArea()
    {
        Console.WriteLine("Printing area of the shape.");
    }
}
