
public class Rectangle : IShape
{
    public double Width { get; set; }
    public double Height { get; set; }

    public void Draw()
    {
        Console.WriteLine($"Drawing a rectangle with width {Width} and height {Height}");
    }

    public double Area()
    {
        return Width * Height;
    }
}
