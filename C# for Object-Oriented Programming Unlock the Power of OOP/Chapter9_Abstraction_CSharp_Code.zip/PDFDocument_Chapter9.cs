
public class PDFDocument : Document
{
    public override void Open()
    {
        Console.WriteLine("Opening PDF document.");
    }

    public override void Save()
    {
        Console.WriteLine("Saving PDF document.");
    }
}
