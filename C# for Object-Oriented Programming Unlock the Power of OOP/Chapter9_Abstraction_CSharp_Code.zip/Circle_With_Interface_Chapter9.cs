
public class Circle : IShape
{
    public double Radius { get; set; }

    public void Draw()
    {
        Console.WriteLine($"Drawing a circle with radius {Radius}");
    }

    public double Area()
    {
        return Math.PI * Radius * Radius;
    }
}
