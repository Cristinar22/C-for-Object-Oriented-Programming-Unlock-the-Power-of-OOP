using System;
using System.Collections.Generic;
using System.Linq;

public class Car
{
    public string Make { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }

    public Car(string make, string model, int year)
    {
        Make = make;
        Model = model;
        Year = year;
    }
}

class Program
{
    static void Main()
    {
        // Creating a list of Car objects
        List<Car> cars = new List<Car>
        {
            new Car("Toyota", "Camry", 2020),
            new Car("Honda", "Civic", 2018),
            new Car("Ford", "Mustang", 2022),
            new Car("Chevrolet", "Malibu", 2019)
        };

        // Using LINQ to filter cars made after 2019
        var recentCars = from car in cars
                         where car.Year > 2019
                         select car;

        // Displaying the result
        Console.WriteLine("Cars made after 2019:");
        foreach (var car in recentCars)
        {
            Console.WriteLine(car.Make + " " + car.Model + " (" + car.Year + ")");
        }
    }
}
