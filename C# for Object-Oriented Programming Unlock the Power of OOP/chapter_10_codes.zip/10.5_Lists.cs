using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Creating a list of integers
        List<int> numbers = new List<int>();

        // Adding elements to the list
        numbers.Add(10);
        numbers.Add(20);
        numbers.Add(30);

        // Accessing elements using indexes
        Console.WriteLine("First number in the list: " + numbers[0]);

        // Looping through the list
        Console.WriteLine("All numbers in the list:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }

        // Removing an element
        numbers.Remove(20); // Removes the first occurrence of 20
        Console.WriteLine("After removing 20, the list contains:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
    }
}
