using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Creating a dictionary
        Dictionary<string, int> phonebook = new Dictionary<string, int>();

        // Adding key-value pairs
        phonebook.Add("Alice", 123456789);
        phonebook.Add("Bob", 987654321);

        // Accessing values using keys
        Console.WriteLine("Alice's phone number: " + phonebook["Alice"]);

        // Checking if a key exists
        if (phonebook.ContainsKey("Charlie"))
        {
            Console.WriteLine("Charlie's phone number: " + phonebook["Charlie"]);
        }
        else
        {
            Console.WriteLine("Charlie is not in the phonebook.");
        }

        // Looping through the dictionary
        Console.WriteLine("Phonebook:");
        foreach (var entry in phonebook)
        {
            Console.WriteLine(entry.Key + ": " + entry.Value);
        }
    }
}
