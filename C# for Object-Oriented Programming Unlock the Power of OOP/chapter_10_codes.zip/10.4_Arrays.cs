class Program
{
    static void Main()
    {
        // Creating an array of integers
        int[] numbers = new int[5];

        // Assigning values to the array
        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;

        // Accessing elements using indexes
        Console.WriteLine("First number: " + numbers[0]);
        Console.WriteLine("Last number: " + numbers[4]);

        // Looping through the array
        Console.WriteLine("All numbers in the array:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
    }
}
