
class Program
{
    static void Main()
    {
        // Creating objects of different types
        Shape shape1 = new Circle();
        Shape shape2 = new Rectangle();

        // Polymorphism in action: calling the Draw method
        shape1.Draw(); // Outputs: Drawing a circle.
        shape2.Draw(); // Outputs: Drawing a rectangle.
    }
}
