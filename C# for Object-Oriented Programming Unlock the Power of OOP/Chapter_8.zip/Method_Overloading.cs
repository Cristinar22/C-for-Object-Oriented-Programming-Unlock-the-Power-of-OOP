
public class Calculator
{
    // Overloaded method to add two integers
    public int Add(int a, int b)
    {
        return a + b;
    }

    // Overloaded method to add two floats
    public float Add(float a, float b)
    {
        return a + b;
    }
}
