
public class Shape
{
    // Base class method
    public virtual void Draw()
    {
        Console.WriteLine("Drawing a generic shape.");
    }
    
    public virtual double Area()
    {
        return 0; // Default behavior
    }
}

public class Circle : Shape
{
    public double Radius { get; set; }
    
    public Circle(double radius)
    {
        Radius = radius;
    }

    public override void Draw()
    {
        Console.WriteLine("Drawing a circle.");
    }

    public override double Area()
    {
        return Math.PI * Radius * Radius;
    }
}

public class Rectangle : Shape
{
    public double Length { get; set; }
    public double Width { get; set; }
    
    public Rectangle(double length, double width)
    {
        Length = length;
        Width = width;
    }

    public override void Draw()
    {
        Console.WriteLine("Drawing a rectangle.");
    }

    public override double Area()
    {
        return Length * Width;
    }
}

class Program
{
    static void Main()
    {
        // Creating Shape objects using derived classes
        Shape shape1 = new Circle(5);
        Shape shape2 = new Rectangle(4, 6);

        // Polymorphism in action: calling Draw and Area methods
        Console.WriteLine("Shape 1: ");
        shape1.Draw();  // Output: Drawing a circle.
        Console.WriteLine("Area of Circle: " + shape1.Area());  // Output: 78.5398...

        Console.WriteLine("
Shape 2: ");
        shape2.Draw();  // Output: Drawing a rectangle.
        Console.WriteLine("Area of Rectangle: " + shape2.Area());  // Output: 24
    }
}
