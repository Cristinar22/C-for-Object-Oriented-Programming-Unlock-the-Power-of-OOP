
public class Shape
{
    // Virtual method that can be overridden by derived classes
    public virtual void Draw()
    {
        Console.WriteLine("Drawing a shape.");
    }
}

public class Circle : Shape
{
    // Overriding the Draw method
    public override void Draw()
    {
        Console.WriteLine("Drawing a circle.");
    }
}

public class Rectangle : Shape
{
    // Overriding the Draw method
    public override void Draw()
    {
        Console.WriteLine("Drawing a rectangle.");
    }
}
